# Campus Flow

Windows 11 的校园网后台认证工具。开机后静默运行，网络断了或认证过期时自动帮你登录，不需要打开浏览器，也不弹任何窗口。

---

## 它解决什么问题

校园网（尤其是高校的 Portal 认证）有个共同的麻烦：**认证会过期**。

- 重启电脑后要重新登录
- 待机唤醒后要重新登录
- 认证有有效期，到期就断网，你得自己发现
- 断线后浏览器不会自动弹认证页，你只会觉得"网怎么没了"

每次都要：打开浏览器 → 等认证页 → 输账号密码 → 关掉。一天来个两三次。

**Campus Flow 把这件事变成零操作。** 它在后台每 60 秒检查一次网络，发现不通就按配置自动提交认证，认证成功后再检查一次就停止轮询，不占 CPU。

---

## 主要功能

| 功能 | 说明 |
|---|---|
| **静默后台认证** | 不打开浏览器，不显示终端窗口，无托盘图标 |
| **只在断网时工作** | 联网时完全不轮询，CPU 占用接近零 |
| **声明式认证配方** | 用 JSON 描述登录流程，支持多步认证、表单提交、JSON 接口 |
| **开机自动启动** | 登录后由 Windows 拉起，无需手动打开 |
| **密码加密存储** | 用 Windows DPAPI 加密，只能被当前用户解密 |
| **全程可排查** | 每一步请求都写日志，认证失败能精确到是哪一步 |
| **不记录敏感信息** | 日志只记未展开的 URL 模板，密码不会写进日志 |

---

## 安装

### 前置条件（重要，不满足则无法自动连接）

**必须先把校园网 Wi‑Fi 设为"自动连接"。** 工具只负责门户认证，不负责让 Windows 连上 Wi‑Fi。

检查方法（PowerShell）：

```powershell
netsh wlan show profile name="你的校园网SSID" | Select-String "连接模式"
```

如果显示 `手动连接`，改成自动：

```powershell
netsh wlan set profileparameter name="你的校园网SSID" connectionmode=auto
```

> 这一步不做的话，现象是：开机后工具报「未检测到可用网络」。**这不是工具的 bug**，是 Windows 没去连 Wi‑Fi。

### 安装步骤

1. 下载 `outputs/CampusFlow-v1314.5.3.0-win-x64.zip`
2. **解压到一个固定位置**，例如 `D:\Tools\CampusFlow\`
3. 双击 `CampusFlow.exe`

> ⚠️ **不要直接从压缩包里运行，也不要解压到临时目录。** Windows 会清理临时文件夹，程序会连同开机自启一起失效。放到一个你不会随手删掉的地方。

普通用户**不需要**安装 Visual Studio、.NET SDK 或任何开发工具——程序是编译好的 exe。

---

## 使用

### 三步配置

**1. 基础设置** —— 填校园网账号和密码

- 账号填**纯学号**，不要自己加后缀（后缀由配方负责）
- 密码框留空 = 沿用上次保存的密码

**2. 认证流程** —— 选择认证配方

下拉里选一个预设：

| 预设 | 适用 |
|---|---|
| `校园网（移动 @gxyyd）` | 已适配的某高校门户（河南安冉云），移动账号 |
| `河北移动（与扁平配置等价）` | 河北移动的老式表单门户 |
| `自定义` | 自己写配方，见下文 |

> 没有你学校的预设？看下面的 [自定义配方](#自定义配方) 一节。**不用改代码。**

**3. 回基础设置 →「保存并启用」**

这一步会同时：保存配置、加密保存密码、开启后台服务、写入开机自启。

### 验证是否生效

点 **「测试登录」**。这个按钮会**强制跑一次真实认证**（联网时也跑），用来验证配置对不对：

- 弹 `认证成功` → 配置正确，收工
- 弹 `认证失败：账号或密码不正确` → 账号、密码或运营商后缀不对
- 弹 `认证失败：第N步 …` → 配方有问题，看「运行日志」页

### 日常使用

配置好之后**不需要再管它**。工具会在后台：

- 每 60 秒检查一次网络
- 发现不通 → 跑一次认证
- 认证成功 → 停止轮询，继续休眠
- 网络状态变化（断线、换网）→ 自动重新开始检查

---

## 输入输出示例

### 输入：认证配方

配方是描述"怎么登录"的 JSON。以已适配的校园网门户为例，实际内容就是：

```json
{
  "name": "校园网（移动 @gxyyd）",
  "settleMs": 2500,
  "successJson": "code",
  "successValue": "0",
  "failureKeywords": "账号或密码不正确|密码错误|账号不存在|已停机",
  "steps": [
    {
      "name": "取门户配置",
      "method": "GET",
      "url": "http://211.69.15.10:6060/PortalJsonAction.do?wlanuserip={local_ip:url}&wlanacname=HAIT-SR8808&viewStatus=1",
      "extractJson": "portalconfig.timestamp;portalconfig.uuid;portalconfig.id",
      "extractAs": "timestamp;uuid;portalpageid"
    },
    {
      "name": "提交认证",
      "method": "GET",
      "url": "http://211.69.15.10:6060/quickauth.do?userid={username:url}@gxyyd&passwd={password:url}&wlanuserip={local_ip:url}&wlanacname=HAIT-SR8808&timestamp={timestamp:url}&uuid={uuid:url}&portalpageid={portalpageid:url}"
    }
  ]
}
```

看不懂没关系——预设已经填好了。这份 JSON 的作用是：**换一所学校只需要换这个 JSON，不用重新编译程序。**

### 输出：运行日志

认证成功时，`%LOCALAPPDATA%\CampusFlow\campusflow.log` 里是这样的：

```
2026-09-19 23:03:42  开始执行配方「校园网（移动 @gxyyd）」，共 2 步
2026-09-19 23:03:42  第1步「取门户配置」 GET http://211.69.15.10:6060/PortalJsonAction.do?wlanuserip={local_ip:url}&...
2026-09-19 23:03:42  第1步「取门户配置」 返回 2234 字节
2026-09-19 23:03:42  第1步「取门户配置」 提取 timestamp = 1789830222510
2026-09-19 23:03:42  第1步「取门户配置」 提取 uuid = 3c471390-f873-4eef-8c23-e6327f22459d
2026-09-19 23:03:42  第1步「取门户配置」 提取 portalpageid = 21
2026-09-19 23:03:42  第2步「提交认证」 GET http://211.69.15.10:6060/quickauth.do?userid={username:url}@gxyyd&...
2026-09-19 23:03:42  第2步「提交认证」 返回 313 字节
2026-09-19 23:03:45  成功判定 code = 0，期望 0
2026-09-19 23:03:45  配方「校园网（移动 @gxyyd）」认证成功
```

注意日志里 URL 显示的是 **`{username:url}` 这样的未展开模板**——密码不会出现在日志里。

失败时（密码填错）：

```
2026-09-19 22:27:05  第2步「提交认证」 返回 318 字节
2026-09-19 22:27:08  配方「校园网（移动 @gxyyd）」门户返回失败信息：账号或密码不正确
```

程序界面上的提示与此对应：

| 日志/界面提示 | 含义 |
|---|---|
| `认证成功` | 门户明确返回了成功 |
| `已提交，但未确认联网` | 请求发出去了，但既没匹配到成功也没匹配到失败。看日志里的响应片段 |
| `认证失败：<门户原文>` | 门户返回了失败原因，原文直接透传 |
| `未检测到可用网络` | Windows 报告没有网络——通常是 Wi‑Fi 没自动连接 |
| `认证失败：门户要求输入验证码` | 见下方「已知限制」 |

### 输出：配置文件

配置保存在 `%LOCALAPPDATA%\CampusFlow\`：

| 文件 | 内容 |
|---|---|
| `settings.xml` | 门户地址、配方、轮询间隔等（明文，不含密码） |
| `credentials.dat` | 账号密码，DPAPI 加密，仅当前 Windows 用户可解 |
| `campusflow.log` | 运行日志，可直接用记事本打开 |

---

## 自定义配方

适用于**没有现成预设**的学校。不需要写代码，只需要描述登录过程。

### 配方字段

**顶层**

| 字段 | 说明 |
|---|---|
| `name` | 配方名，用于日志 |
| `steps` | 步骤数组，**按顺序执行** |
| `settleMs` | 最后一步之后等待多久再判断结果，默认 1800 |
| `successJson` / `successValue` | 响应 JSON 里某个字段等于某个值即成功（如 `code` = `0`） |
| `failureKeywords` | `\|` 分隔。响应里出现任一即判定失败 |
| `verifyConnectivity` | 是否用联网探测兜底判断，默认 true |

**每一步**

| 字段 | 说明 |
|---|---|
| `name` | 步骤名，仅用于日志 |
| `method` | `GET` 或 `POST`，默认 `POST` |
| `url` | 请求地址，支持变量 |
| `headers` | 请求头，逐行 `名称: 值` |
| `body` | 请求体，支持变量 |
| `extract` | 正则提取，有捕获组取组 1 |
| `extractJson` | JSON 点路径提取，如 `data.token`（与 `extract` 二选一） |
| `extractAs` | 提取结果存入哪个变量 |
| `expectContains` | 响应里没有此内容则本步失败 |

### 可用变量

`{local_ip}`（本机内网 IPv4）、`{mac}`、`{hostname}`、`{username}`、`{password}`、`{portal_url}`，以及前面步骤用 `extractAs` 提取到的任意变量。

- **未知变量原样保留**，方便一眼看出哪个占位符没被替换
- 加 `:url` 修饰符可做百分号编码：`{password:url}`。**GET 把账号密码放查询串时必须加**，否则密码里的 `&`、`=` 会把请求拆坏

### 并列提取

一次响应可以提取多个值，用分号分隔：

```json
"extractJson": "portalconfig.timestamp;portalconfig.uuid;portalconfig.id",
"extractAs":   "timestamp;uuid;portalpageid"
```

两边的项数必须一致，否则「校验」会报错。

### 怎么知道该怎么写

1. 浏览器打开你们学校的认证页
2. 按 `F12` → **网络**（Network）标签 → 勾选 **保留日志**
3. 手动登录一次
4. 找到那条 **POST**（或 GET）请求，看它的**网址**、**请求头**、**请求体**
5. 照抄进配方，把账号密码的位置换成 `{username}` / `{password}`

---

## 已知限制

- **验证码**：门户要求输验证码时，工具会明确报出来并停止，不会假装成功。**这是无法自动化的**，没有绕过的办法。
- **密码加密**：如果门户在网页里用 JavaScript 对密码做了 RSA/AES 加密再提交，本工具的配方模型无法表达，需要改代码。已适配的门户是明文提交，不涉及这个问题。
- **仅 Windows**：依赖 .NET Framework 和 Windows DPAPI。
- **开机启动有延迟**：由 Windows 决定何时拉起注册表里的自启项，实测约 3 分钟。启动后 500ms 内开始首次检查。

---

## 项目结构

```
CampusFlow/
├── work/                            源码与构建脚本（改代码看这里）
│   ├── CampusAutoLogin.cs           全部程序逻辑，单文件
│   ├── SelfCheck.cs                 自检程序（不参与主构建）
│   ├── Build-CampusAutoLogin.ps1    编译脚本
│   └── Run-SelfCheck.ps1            跑自检
└── outputs/                         发布产物
    ├── CampusFlow.exe               可直接运行
    ├── CampusFlow-v1314.5.3.0-win-x64.zip
    ├── src/                         work/ 源码的副本（打包用）
    └── build.ps1                    在发布包内独立编译
```

---

## 开发者：构建与测试

**不需要装任何开发工具。** Windows 11 自带 .NET Framework 的 C# 编译器。

```powershell
# 编译 → outputs/CampusFlow.exe
powershell -File .\work\Build-CampusAutoLogin.ps1

# 自检：配方解析与校验、JSON/正则提取、模板替换、字符集、配置向后兼容
# 全过时退出码为 0，失败时退出码 = 失败项数
powershell -File .\work\Run-SelfCheck.ps1
```

**不需要** `-ExecutionPolicy Bypass`——本地脚本在默认的 `RemoteSigned` 策略下可以直接运行。

### 改代码前必读

1. **只能是 C# 5 语法。** 自带编译器只支持到 C# 5：不能用字符串插值、`?.`、`nameof`、表达式体成员、局部函数、`out var`。
2. **全部逻辑在 `work/CampusAutoLogin.cs` 一个文件里**，没有 .csproj。
3. **`.ps1` 文件必须保留 UTF-8 BOM。** PowerShell 5.1 对没有 BOM 的脚本按系统 ANSI 码页（中文系统为 GBK）解码，中文会被读坏，轻则乱码重则引号被吃掉导致解析失败。
4. 打包发布 zip 时记得把 `work/CampusAutoLogin.cs` 复制到 `outputs/src/`——构建不会自动同步。

### 没有你学校的预设？

欢迎把配方提上来。**只需要加一个 JSON 预设，不用改架构。** 附上你抓到的登录请求（账号密码请打码）。

---

## 更新日志

### 1314.5.3.0

- 新增声明式「认证流程」配方，支持多步认证和 JSON 接口，不再局限于单次表单提交。
- 自动识别表单失败的场景（前端框架渲染的门户）现在可以靠配方绕开。
- 内置「校园网（安冉云门户）」预设：GET `/quickauth.do`、账号带运营商后缀、密码明文。
- 变量支持 `:url` 修饰符（GET 把密码放查询串时必须编码）；提取规则支持分号并列列表，一次响应可提取多个值。
- 新增配方级 `successJson` / `successValue`：JSON 接口的成功码（如 `code == "0"`）直接判定成功，不再依赖联网探测——校园网放行常有几秒延迟，探测容易抢跑而误报。
- 新增配方级 `failureKeywords`，门户返回的中文失败原因会被识别，不再误报成「已提交，但未确认联网」。
- 修复「测试登录」在联网时什么也测不了的问题：现在强制跑一次认证（后台服务仍保留「已联网就跳过」）。
- 修正常见于国内校园网的 GBK/GB2312 门户响应被按 UTF-8 解码导致乱码、成功关键字永远匹配不上的问题。
- 修正常用受限请求头（如 Host/Connection）导致整步以不透明错误失败的问题。
- 配置文件新增 `SchemaVersion`，旧配置原样读取并自动升级；未使用配方时行为与之前完全一致。
- 修复配方级 `verifyConnectivity` 实际默认为关闭的问题（`bool` 字段默认 false，而设计意图是开启）：改用可空类型区分"没写"和"写了 false"。
- 新增 `work/SelfCheck.cs` 自检程序与 `work/Run-SelfCheck.ps1`。
- 修复 `outputs/build.ps1` 从未能使用的问题（路径按位置解析错误）。

### 1314.5.2.0

- 默认改为直接访问校园网门户，不再依赖 Windows 的 `msftconnecttest.com` 重定向。
- 移动校园网模板的登录页和提交地址自动携带 `{local_ip}`、`wlanacname` 参数。
- 兼容旧版本设置文件，首次启动时自动迁移旧的固定 `/login.do` 地址。
- 认证失败时记录 HTTP 状态码（例如 500），但不记录账号和密码。
- 网络认证成功后停止定时轮询，断网或网络地址变化时再自动唤醒。
- 普通用户无需安装编译器，解压发布包后直接运行 `CampusFlow.exe`。
